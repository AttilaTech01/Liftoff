export interface SimpleItem {
    id: number;
    value: string;
}