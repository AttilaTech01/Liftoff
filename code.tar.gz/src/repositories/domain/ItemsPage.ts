import { Item, ItemConverter } from './Item';

export interface ItemsPage {
    cursor?: string;
    items?: Item[];
}

export class ItemsPageConverter {
    public static convertToItemsPage(data: ItemsPage): ItemsPage {
        return {
            cursor: data?.cursor,
            items: data?.items?.map(item => ItemConverter.convertToItem(item))
        };
    }
}